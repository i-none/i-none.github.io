------------------------------------------Credits-------------------------------------------
--				Minicord made by GLadiator
--it was originally a script "DT Changer" by Intranets, but it has almost completely changed
------------------------------------------Credits-------------------------------------------

------------------------------------------------------------------------------------------------------
client.Command("toggleconsole", true)
client.Command("clear", true);
client.Command("echo \"hG&&&&GGGG&&&GGGGGhh933X3933999G&&GGGh9X2X33993X555X3399hGGGGhh9hh9325XXXXX22555X999hhhhGG&&&&&&AAAA&AAAAAAAAA\"", true);
client.Command("echo \"h&&&&&&&GGGGGGGGGGhh93339hGhhhG&&&&GG93333hh9993333X2555233999hh9X2X3XXXXX2522X3222X9hGGGGG&&&&&AAAAAAAAAA&&&G\"", true);
client.Command("echo \"&&&GGG&GGhhGhhhGhGhh939hhG&&GhG&&&GGh93339999h933X2SiSS52XX3XXXX222255XXX33XXXX2X9X523hGG&GGGG&&AAA&&AG9999hhh\"", true);
client.Command("echo \"GGGGGGGG&&&&GGhhhGGhh99hhGG&GGGGGh93X255555555SSSiS5525SSSS5555555222X39hhh93999XX39X2X9GGGGGG&&AAAA&&&GGh99hh\"", true);
client.Command("echo \"hGG&Gh9hhh9933333hhhhhhGGGG&&G9332Sisr;;;;;;::::::;r;rrsrrrssssi2XX39h9hhGGGGhhGh99h9X2XGhhhGhhG&AAAA&GhGG&&GG\"", true);
client.Command("echo \"&AAAA&9333355X999hGhGGhGhGhh9X5Sisr::,,........,.....,,:;;;;::;riS55555233hhhGGGhGhhGG3XX999hhGG&AAAAAh9hGGG&G\"", true);
client.Command("echo \"&AAAAAG9322523hhGGG&&GGGG9X2Ssrrr::,,,....      ..   . .,,:::::;rrsii2X2552X333339h99hh9X2XXX3hGG&&A&&h3hG2S&G\"", true);
client.Command("echo \"&AAA&&A&h9339hG&&&&&&Gh932Sis;;:,,,,,....            ....,:,,,,,::rrssi5X33X2X32S239h99hh93333399hGAAAhhG&GX&G\"", true);
client.Command("echo \"&&AAAAAA&GhhhG&&&&&&GG9X5Ssr;:::,,,......                ..,,,,,,,,:;iSSiSX99352X5S23333993XX39X2X3h&A&GG&G39G\"", true);
client.Command("echo \"&&AAA&&&h939hhGG&GGhh325isrr;::,,,....   This is esoterik    ,;:::;:;rri5255X39999XSSSS52X39XX9h933hG&&&GG3XX2\"", true);
client.Command("echo \"&AAA&&&Gh3253G&&&Ghh935isrr;::,,...He thinks he has the best cheat.,,,,::rS3X2X9hhh9X555555X933h939G&&G&&h93XX\"", true);
client.Command("echo \"&&AAAA&G3XX9GGGGGhh9X5issr;;:,,.It has the best feature ever created...,,,:;ri5239hGh93XX22233X9G9253AG9GG99hh\"", true);
client.Command("echo \"G&A&&&&GhhhGG&&GGh932Sisr;;:,Although she has been in aimware since 2020,,,::;rsi529hGGh99339999h92SXGG9&A&G&&\"", true);
client.Command("echo \";S9&&&GGhGGGGGGhGh32Sisr;:::,,...There is no better cheat than his....,:;::::::;rssiSX9hGhhhhG&&GG939A&hGGGGGG\"", true);
client.Command("echo \".,;5hh99hGGGGGGGh32SSisr;::,,,,..His cheat will cracked? Well, okay,,,,,;;::::::;rssi5X3hGGGGGG&&&hhGAAhh&GhX2\"", true);
client.Command("echo \"5SiS29hhhhGGGGG99X5iisr;::::,,,.....He wants to crack rarely.win.......,,,,:::::;;rsiS2X3GG&GGGG&&G39&A&hhhGhh\"", true);
client.Command("echo \"993339hhhGG&&Gh9X2Sissr;::::,,........but still unsuccessful :((........,,::::::;;rsiS2X39hG&&GG&&&99&AAAAAAAA\"", true);
client.Command("echo \"hhh999hhhGG&&Gh935isss;::::,,He'll just drop everything and do nothing.,,,::::::;;;riS2239hGGGGGG&&G9h&&AAAAAA\"", true);
client.Command("echo \"hhhGGhhhhGGGG&G935isrrr;::,,...    .                        ....... .....,::;;:::;;riS5239hhhGh9h&&&G99hGAAAAA\"", true);
client.Command("echo \"hhG&Ghhhhhhh999325isrr;;;;:,.. ..,:::,.                  .,;rsiSisr;;::;:,,:;;;;;:;riS52X3999hhhhG&&&9SSSXGAAA\"", true);
client.Command("echo \"529G99hhhhGh3XX225srrrrrr;,,,,;rsiisrr;,                .,;siS5552555SSSisr,,;rr;;::ri2X339999GGGhhGG9SSS23GAA\"", true);
client.Command("echo \"SiS2X3hhhGGh93X25Ssrrrss;::;ri555Siis;:,.                ,,,,;;rr;rrsiS55SSir;rrr;;;rs533999hhG&h99hG95223h&AH\"", true);
client.Command("echo \"3SiS529hhGhh99325SsrrrsssiSS555Sisr;:,,..               ........ .      .:sS5Ssss;;;;rS2X39hGhGGGhhhh9399hG&AA\"", true);
client.Command("echo \"G2SS55999hGG93XX5SsrssS52X25Sir;;:::,,,,,.             ...    ..,,,,,,.  .,:;siisrrrrri533hGhhhhGGGGhGhh9hGGGG\"", true);
client.Command("echo \"93SiSi5hhGGh99325issii225ir:....,::;;;:::,,...      .....    ,:sSi522S;:.  ..,rssrrrrsS239999hhGGGGhh99333XXXX\"", true);
client.Command("echo \"X3X25S5XhhhGh93X5issiS5ir:,,,:;;;rrsi;:,,,;::..    .,,,..,,:,..,sSisSiSSs:   .,;rrrrrsS2399999hG&Ghhhhh9hh9933\"", true);
client.Command("echo \"23X5SS5X9hhhhh9X5isiSSsr:::;rsiS5;.;r. .:::;:,..   .,,,,.  .,,,,,..,,,::,,.  .,,:;;rrsS29999hhhG&GG&&&&&&G&GGh\"", true);
client.Command("echo \"5XSiii5X39h99h932Siiisr::;ri5irrssrr;::,.:;;:,,.....,,,,::,........  .........,.,;rrrrS29hhhhhhhhGhGG&&GGGGhhh\"", true);
client.Command("echo \"SSSiii5239h9999X2iiiss;::;rsr;;::,.. .,::;;;:,,......,,,,,::,,,,,........   ...,,:;;rsS299h35isi5999hGGGGGhhhG\"", true);
client.Command("echo \"555SiSS23339hh932issrr::::,::,,,,,,,,:::::::::,....,,,,,.....,,,,,,.....      ..,::;rsSX9h95r;,:;S3hhhhGGGGG&&\"", true);
client.Command("echo \"2XhX5555X999hh93XSssr;:,,,....,,,,,,,,,,.,:;;:,...,,,,,..    ...................,:;rrsSX992s:,,,,r5hhhhG&&GGG&\"", true);
client.Command("echo \"52h3555S5X99hhh3XSssr;,,....,,,,,,,,... .,:;;:....,,:::,.          .............,:;sssSX32s,. .. ,s39hhG&&&&&&\"", true);
client.Command("echo \"2X32555S52X5S299XSsr;:,....,,.,....     .:;;:,. ...,:::::.              ........,:;sssS2Xi:    ..:rX9hhhhhGGGG\"", true);
client.Command("echo \"223h2255522irr53XSsr;:,....,...         ,;;;,,... .,::::::,               .....,,:;rsiiSs:.    .,:rX339999hGGh\"", true);
client.Command("echo \"552h9X5S52S;,,;5XSsr;:,,......         ,;;:,,.. ...,,,,..,,.                ...,::;sssir:.      ,:r2XXX3339999\"", true);
client.Command("echo \"SS2X25SS52S;..,s55ir;;:,,,..          .,:,,,.       ..,...,,                 .,,:;rssisr,       ,riXX22XX3XX33\"", true);
client.Command("echo \"55XX55555XS;,,,,;SSs;;::,,..          .,,,,,.       ...,:::.                 .,::;rsiis;,.     .:s5XX222222X33\"", true);
client.Command("echo \"2X9925SS5X2r,,   ,sirr:::,.           .,::::,,.    .,,,,,,..                 .,,;rrsisr,.,,,.,.:rSXXXXX22222XX\"", true);
client.Command("echo \"GG&GGG35S2Xi:.    ,rsr;;:,..          ..,,,,,:,,..,,....,,,..                ..,:rrsss;,    .,,;s5X33X255552XX\"", true);
client.Command("echo \"&GGGGGGGX2XXs,.   .:rr;;::..         ..,:,:,,.......  ...,,,,..           ......:rssis;,.. .,::iS22393255552XX\"", true);
client.Command("echo \"GGGGGGG&&9335r,....,;rr;:,,.        ..,:::::,....      .,,,,,,,....            .:rrrsr,   .,:rS5X22X3325552XXX\"", true);
client.Command("echo \"GGGGGGGGGGGG9i;:,..,:rr;::,,        .,::::,,,...       ....,,,,,,,,,,.        ..:sssiis;  .:ri22222X393252XXXX\"", true);
client.Command("echo \"GG&&&&&&&&&&&3r::,..,;r;::,,   ...,,,,::::,,..          ...........,,,.    ....,;rssiS2XG3225222222X399X222XXX\"", true);
client.Command("echo \"&&&&GGG&&&&&&G3s;:...:r;:,,,. .,,,,:::,,,,,,...    .....,,,,...........   .....,rrriiS5XGGh32222222XX99X222222\"", true);
client.Command("echo \"&&&&GG&&&&&&&&G3S:.  ,rr:,:,...,,,,,,,,,:;;r;;;;;;:;;;;rrrrrrr;::,.....   ..,.,:rrrsii5X9h9X22222552X99X252225\"", true);
client.Command("echo \"&&&&G&&&G&&&&GGGG35ii52i;,,:....,...,::rrsiisrrrr;;;;;;::;;:::,,,,,,,.    .,,,,:;;rsssSX9h9X222X2222X393255555\"", true);
client.Command("echo \"&&GGG&GG&&&GGGGGGGGGGG95s:::,...,,,,,,,::::::,,,,.............,,......   .,,,,:;;;rsrri2399X222X252XX39X255522\"", true);
client.Command("echo \"GGGGGGGGGGG&GGGGGGGGGGhXir;;:.........,,,,,,.,,..................,...    .,,,:;;:;rsrri2XXXXX22X2252X332555522\"", true);
client.Command("echo \"&&GGGGGG&GGGGGGGGGGGGGh35srr;,.  ...,,,,,,..,,,,,,,,.....      ......   .,,,:;;;;rsrrrsSX3XXX22XX252X33X555222\"", true);
client.Command("echo \"GGG&GGGGG&&GGGGGGGGGGGGhXisrr;,....,,,,,,... ......,...       .........,,,::;r;;;ssr;rsiX33XXXXXXX22X33X255522\"", true);
client.Command("echo \"GGGGGGGGGGGGGGGGGGGGGGGG95iisr;:,..,,,,,....      ..          .....,,,,:::::;r;rrisr:;sSX99X22XXX2552X32555222\"", true);
client.Command("echo \"GGGGGGGGGG&GGGGGGGGGGGGGG35Sissr:,,,,,,,..  .......... .      ....,,:::,,,:;rrrrsss;:;rS393XX2XXXXX2XXX2555522\"", true);
client.Command("echo \"GGGGG&&&&GGGGGGGGGGGGGGGGG9XSisrr;::,,,,,,........................,,:::::::rrrssssr;:;rS3h933XXX33X22XX25S5555\"", true);
client.Command("echo \"GGGGGGGGGGGGGGGGGGGGGGGGGGGG35isssr;:,,,,,,,,,................,,,,,::;;:::;rrrssrrr::;s59GGGGGhh933XX3322SS555\"", true);
client.Command("echo \"GGGGGGGGGGGGGGGGGGGGGGGGGGGGGhXSissr;:,,,,::,,,..    .....,,,..,,:::;;;;;;rrrrrr;;;:::s59GGGGGGGhhhhh993X5S555\"", true);
client.Command("echo \"GGGGGGGGGGGGGGGGGGGGGGGGGGGGGG355Siir;::,,:::,,,.    ......,,,,,:::;;;;rrrrrrrr;:;:::;s59GGGGhGGGGGGGGGGGh9933\"", true);
client.Command("echo \"GGGGGGGGGGGGGGGGGGGGGGGGGGGGGG92SSSSis;::,,,,,,,.   .......,,,,::;rrrrrrrrr;;;:::::,:;sS3hhGhGGGGGGGGGGGGGGGGG\"", true);
client.Command("echo \"GGGGGGGGGGGGGGGGGGGGG&GGGGGGGhh35S522SSsr;:::,,,.....,.,,,,,,::;rrssrr;;;;:::::,:,,,::sSX9GGGhhGhGGhhhhhhGGGGG\"", true);
client.Command("echo \"GGGGGGGGGGGGGGGGGGGGGGGGGGGGhhh92SS52X22isr;;::,,,,,,,,,,:,::;rssssr;:,,,,,,,,,,,,,,:;si53GhGGGGGGGGGGGGGGGGGG\"", true);
client.Command("echo \"GGGGGGGGGGGGGGGGGGGGGGGGGGGhhhh9XSiiS52225SSsr;:::::::::;;rsssisrr;,,.....,,,,,,,,,,,;siiS222X2XX333399hhhhhhh\"", true);
client.Command("echo \"GGGGGGGGGGGGGGGGGGGGGGGGGGhhhhGh9SiiiiS55SSSSSiiisssssssssssssr;::,.   ...,,,,,,.,,,:;rsiiisiiiSS55522X33XXXX2\"", true);
client.Command("echo \"GGGGGGGhGGGGGGGGGGGGGGhGhhhhhhhh92isrssSSSisrrssssssrrrrr;;;;;:,,..     ...........,:;rssssSsiiiSSSS55252Ssss5\"", true);
client.Command("echo \"GGGGGGGhGGGGGGGGGhhhhhhhhhhhhhh992isrrriSiisrr;;;;;;:::::::,:,...        ..........,,:rrsrrr,:. ,;;;rs25iiSS2r\"", true);



------------------------------------------------------------------------------------------------------
local function time_to_ticks(a)
    return 
    math.floor(1 + a / globals.TickInterval())
end
local function toint(n)
    local s = tostring(n)
    local i, j = s:find('%.')
    if i then
        return tonumber(s:sub(1, i-1))
    else
        return n
    end
end
------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------
local sv_maxusrcmdprocessticks = gui.Reference('Misc', 'General', 'Server', 'sv_maxusrcmdprocessticks')
local Fakeduck = gui.Reference('Ragebot', 'Anti-Aim', 'Extra', 'Fake Duck')
local AutosniperHitchance = 'rbot.accuracy.weapon.asniper.hitchance'
local AutosniperDTHitchance = 'rbot.accuracy.weapon.asniper.doublefirehc'
local AutoPeek = gui.Reference('Ragebot', 'Accuracy', 'Movement', 'Auto Peek Key')
------------------------------------------------------------------------------------------------------
--local font = draw.CreateFont('Andre V', 17)
--draw.SetFont(font)
--local x, y = draw.GetScreenSize()
--local w, h = draw.GetTextSize('16 TICKS')
--local DrawingOverRapidfireX = toint(x / 2 - (w / 2))
--local DrawingOverRapidfireY = toint(y / 1.073 - (h / 2))

local Curtime = globals.CurTime()
local State = true
------------------------------------------------------------------------------------------------------
local MinicordTab = gui.Tab(gui.Reference('Ragebot'), 'minicord.tab', 'Minicord')
local MinicordGroupboxRagebotPTICKS = gui.Groupbox(MinicordTab, 'Ragebot | Maximum process ticks', 16, 16, 296, 200)
local MinicordGroupboxRagebotDTFD = gui.Groupbox(MinicordTab, 'Ragebot | Double fire and Fakeduck', 16, 212, 296, 200)
local MinicordGroupboxRagebotFL = gui.Groupbox(MinicordTab, 'Ragebot | Fakelags', 328, 16, 296, 200)
local MinicordGroupboxRagebotAutoNoscope = gui.Groupbox(MinicordTab, 'Ragebot | Autosniper noscope/scope hit chance', 328, 266, 296, 200)
local MinicordGroupboxMisc = gui.Groupbox(MinicordTab, 'Misc', 16, 742, 296, 200)
local MinicordGroupboxVisuals = gui.Groupbox(MinicordTab, 'Visuals', 328, 632, 296, 200)
------------------------------------------------------------------------------------------------------

local maxprocessticks_combo = gui.Combobox(MinicordGroupboxRagebotPTICKS, 'minicord.rbot.sv_maxusrcmdprocessticks_combo', 'Server type', 'Automatic', 'Custom');
local maxprocessticks_slider = gui.Slider(MinicordGroupboxRagebotPTICKS, 'minicord.rbot.sv_maxusrcmdprocessticks_slider', 'Maximum process ticks adjuster', 16, 3, 61);

local doublefire_enable = gui.Checkbox(MinicordGroupboxRagebotDTFD, 'minicord.rbot.doublefire.enable', 'Enable double fire', false);
local doublefire_mode = gui.Combobox(MinicordGroupboxRagebotDTFD, 'minicord.rbot.doublefire.mode', 'Double fire mode', 'Standard', 'Speed burst + lag on peek [beta]');
local doublefire_prediction_mode = gui.Combobox(MinicordGroupboxRagebotDTFD, 'minicord.rbot.doublefire.prediction.mode', 'Prediction velocity mode', 'Static', 'Dynamic [beta]');
local doublefire_prediction_value = gui.Slider(MinicordGroupboxRagebotDTFD, 'minicord.rbot.doublefire.prediction.value', 'Prediction velocity amount', 0.150, 0.080, 0.225, 0.005);
local doublefire_speed = gui.Combobox(MinicordGroupboxRagebotDTFD, 'minicord.rbot.doublefire.speed', 'Double fire speed', 
						'Automatic', 'Slow', 'Delayed', 'Slightly delayed', 'Standard', 
						'Accelerated', 'Use the "Maximum process ticks adjuster" value');
						

local fakeduck_type = gui.Combobox(MinicordGroupboxRagebotDTFD, 'minicord.rbot.fakeduck.speed', 'Fakeduck type', 'Automatic', 'Accurate, but slow', 'Inaccuracy, but fast');
local fakeduck_speed_accuracy = gui.Combobox(MinicordGroupboxRagebotDTFD, 'minicord.rbot.fakeduck.accuracy', 'Fakeduck speed',
						'Slow', 'Slower', 'Standard', 'Faster (unstable)', 'Fast (unstable)', 'Use the "Maximum process ticks adjuster" value');
local fakeduck_speed_inaccuracy = gui.Combobox(MinicordGroupboxRagebotDTFD, 'minicord.rbot.fakeduck.inaccuracy', 'Fakeduck speed',
						'Slow (stable)', 'Slower', 'Standard', 'Use the "Maximum process ticks adjuster" value');

local fakelags_type = gui.Combobox(MinicordGroupboxRagebotFL, 'minicord.rbot.fakelags.type', 'Fakelags mode', 'Automatic', 'Static', 'Jitter');
local fakelags_factor = gui.Slider(MinicordGroupboxRagebotFL, 'minicord.rbot.fakelags.factor', 'Fakelags factor', 16, 3, 61);
																								
local revolver_check = gui.Checkbox(MinicordGroupboxRagebotFL, 'minicord.rbot.revolver', 'Limiting on Revolver R8', false);

local nonescopehc_enable = gui.Checkbox(MinicordGroupboxRagebotAutoNoscope, 'minicord.rbot.noscopehc.enable', 'Enable', false);
local nonescopehc_scope = gui.Slider(MinicordGroupboxRagebotAutoNoscope, 'minicord.rbot.noscopehc.scopevalue', 'Scope hit chance', gui.GetValue(AutosniperHitchance), 0, 100);
local nonescopehc_dt_scope = gui.Slider(MinicordGroupboxRagebotAutoNoscope, 'minicord.rbot.noscopehc.scopefdvalue', 'Scope double fire hit chance', gui.GetValue(AutosniperDTHitchance), 0, 100);
local nonescopehc_regular = gui.Slider(MinicordGroupboxRagebotAutoNoscope, 'minicord.rbot.noscopehc.noscopevalue', 'Noscope hit chance', gui.GetValue(AutosniperHitchance) / 2.5, 0, 100);
local nonescopehc_dt_regular = gui.Slider(MinicordGroupboxRagebotAutoNoscope, 'minicord.rbot.noscopehc.noscopefdvalue', 'Noscope double fire hit chance', gui.GetValue(AutosniperDTHitchance) / 5, 0, 100);

local autopeek_settings = gui.Multibox(MinicordGroupboxMisc, 'Autopeek settings');
local dt_on_autopeek_pingspike = gui.Checkbox(autopeek_settings, 'minicord.other.dtautopeek.pingspike', 'Use fakelatency', false);
local dt_on_autopeek_freestanding = gui.Checkbox(autopeek_settings, 'minicord.other.dtautopeek.freestanding', 'Use freestanding', false);
local dt_on_autopeek_optimalticks = gui.Checkbox(autopeek_settings, 'minicord.other.dtautopeek.optimalticks', 'Force shifting optimal ticks', false);
local dt_on_autopeek = gui.Checkbox(MinicordGroupboxMisc, 'minicord.other.dtautopeek', 'Double fire with autopeek', false);

local draw_ticks = gui.Checkbox(MinicordGroupboxVisuals, 'minicord.draw.ticks', 'Draw ticks on screen', false);
local draw_circle = gui.Checkbox(MinicordGroupboxVisuals, 'minicord.draw.circle', 'Draw choke indicator on the crosshair', false);
local draw_ticks_color = gui.ColorPicker(draw_ticks, 'minicord.draw.ticks.color', 'Draw color', 0, 220, 83, 255);
local draw_circle_color = gui.ColorPicker(draw_circle, 'minicord.draw.circle.color', 'Draw color', 0, 220, 83, 255);

local force_crosshair = gui.Checkbox(MinicordGroupboxVisuals, 'minicord.other.crosshair', 'Force crosshair', false);
local aspect_ratio = gui.Slider(MinicordGroupboxVisuals, "minicord.other.aspectratio", "Aspect ratio", 100, 75, 160)
local night_mode = gui.Slider(MinicordGroupboxVisuals, 'minicord.other.exposure.slider', 'World exposure', 100, 1, 100);
------------------------------------------------------------------------------------------------------
maxprocessticks_combo:SetDescription("Select the server type or leave the automatic mode.")
maxprocessticks_slider:SetDescription("Manual adjuster sv_maxusrcmdprocessticks.")
fakelags_type:SetDescription("Choose your preferred fakelag mode.")
fakelags_factor:SetDescription("How many fakelags ticks will be choked.")
revolver_check:SetDescription("Limit the factor on the Revolver R8 if it shoots under you.")
doublefire_enable:SetDescription('Bind this to turn double fire on and off by key.')
doublefire_mode:SetDescription('Select the desired double fire mode.')
doublefire_prediction_mode:SetDescription('Select the prediction velocity mode for lag peek.')
doublefire_prediction_value:SetDescription('A high value activates lag earlier. Default value is average.')
doublefire_speed:SetDescription("Select double fire speed, or leave automatic.")
fakeduck_type:SetDescription("Choose your preferred fakeduck type, or leave automatic.")
fakeduck_speed_accuracy:SetDescription("This affects the rate of fire and accuracy.")
fakeduck_speed_inaccuracy:SetDescription("This affects the rate of fire and accuracy.")
nonescopehc_enable:SetDescription("Use if you want to shoot with autosniper without scoping.")
nonescopehc_scope:SetDescription("Minimum chance to hit while scoping.")
nonescopehc_dt_scope:SetDescription("Minimum double fire chance to hit while scoping.")
nonescopehc_regular:SetDescription("Minimum chance to hit whitout scoping.")
nonescopehc_dt_regular:SetDescription("Minimum double fire chance to hit whithout scoping.")
autopeek_settings:SetDescription("Settings for autopeek.")
dt_on_autopeek_pingspike:SetDescription("Fakelatency during autopeek for a longer backtrack.")
dt_on_autopeek_freestanding:SetDescription("Freestanding for a safer peek with autopeek.")
dt_on_autopeek_optimalticks:SetDescription("Shifting optimal value for double fire during autopeek.")
dt_on_autopeek:SetDescription("Always use double fire when autopeek is active.")
draw_ticks:SetDescription("Displaying ticks above the rapid fire indicator.")
draw_circle:SetDescription("Choke circle display on crosshair.")
force_crosshair:SetDescription("Always display a crosshair on any weapon.")
aspect_ratio:SetDescription("Expanding or narrowing the play space.")
night_mode:SetDescription("Exposure, or simply the most correct night mode.")
------------------------------------------------------------------------------------------------------

--Main
local function handlemain()
	if maxprocessticks_combo:GetValue() == 0 then
		maxprocessticks_slider:SetDisabled(true)
	elseif maxprocessticks_combo:GetValue() == 1 then
		maxprocessticks_slider:SetDisabled(false)
	end
	
	if doublefire_mode:GetValue() == 1 then
		doublefire_prediction_mode:SetDisabled(false)
		doublefire_prediction_value:SetDisabled(false)
	else
		doublefire_prediction_mode:SetDisabled(true)
		doublefire_prediction_value:SetDisabled(true)
	end
	
	if doublefire_speed:GetValue() == 6 then
		maxprocessticks_slider:SetDisabled(false)
	end
	
	if fakeduck_type:GetValue() == 0 then
		fakeduck_speed_inaccuracy:SetDisabled(true)
		fakeduck_speed_inaccuracy:SetInvisible(false)
		fakeduck_speed_accuracy:SetDisabled(true)
		fakeduck_speed_accuracy:SetInvisible(true)
	elseif fakeduck_type:GetValue() == 1 then
		fakeduck_speed_inaccuracy:SetDisabled(true)
		fakeduck_speed_inaccuracy:SetInvisible(true)
		fakeduck_speed_accuracy:SetDisabled(false)
		fakeduck_speed_accuracy:SetInvisible(false)
		if fakeduck_speed_accuracy:GetValue() == 5 then
			maxprocessticks_slider:SetDisabled(false)
		end
	elseif fakeduck_type:GetValue() == 2 then
		fakeduck_speed_inaccuracy:SetDisabled(false)
		fakeduck_speed_inaccuracy:SetInvisible(false)
		fakeduck_speed_accuracy:SetDisabled(true)
		fakeduck_speed_accuracy:SetInvisible(true)
		if fakeduck_speed_inaccuracy:GetValue() == 4 then
			maxprocessticks_slider:SetDisabled(false)
		end
	end
	
	if fakelags_type:GetValue() == 0 then
		fakelags_factor:SetDisabled(true)
	else
		fakelags_factor:SetDisabled(false)
	end
	
	if not nonescopehc_enable:GetValue() then
		nonescopehc_scope:SetDisabled(true)
		nonescopehc_dt_scope:SetDisabled(true)
		nonescopehc_regular:SetDisabled(true)
		nonescopehc_dt_regular:SetDisabled(true)
	else
		nonescopehc_scope:SetDisabled(false)
		nonescopehc_dt_scope:SetDisabled(false)
		nonescopehc_regular:SetDisabled(false)
		nonescopehc_dt_regular:SetDisabled(false)
	end
	
	if not dt_on_autopeek:GetValue() then
		dt_on_autopeek_optimalticks:SetDisabled(true)
		dt_on_autopeek_optimalticks:SetValue(false)
	else
		dt_on_autopeek_optimalticks:SetDisabled(false)
	end
end
callbacks.Register('Draw', handlemain)

--------------------------------

--Double Fire bind
local function dtbind()
	if not engine.GetServerIP() then
		return
	end
	if not entities.GetLocalPlayer():IsAlive() then
		return
	end
	
	if doublefire_mode:GetValue() == 0 then
		if doublefire_enable:GetValue() then
			gui.SetValue('rbot.accuracy.weapon.asniper.doublefire', 2)
			gui.SetValue('rbot.accuracy.weapon.scout.doublefire', 2)
			gui.SetValue('rbot.accuracy.weapon.sniper.doublefire', 2)
			gui.SetValue('rbot.accuracy.weapon.hpistol.doublefire', 2)
			gui.SetValue('rbot.accuracy.weapon.pistol.doublefire', 2)
		else
			gui.SetValue('rbot.accuracy.weapon.asniper.doublefire', 0)
			gui.SetValue('rbot.accuracy.weapon.scout.doublefire', 0)
			gui.SetValue('rbot.accuracy.weapon.sniper.doublefire', 0)
			gui.SetValue('rbot.accuracy.weapon.hpistol.doublefire', 0)
			gui.SetValue('rbot.accuracy.weapon.pistol.doublefire', 0)
			gui.SetValue('misc.speedburst.enable', false)
		end
	else
		gui.SetValue('rbot.accuracy.weapon.asniper.doublefire', 0)
		gui.SetValue('rbot.accuracy.weapon.scout.doublefire', 0)
		gui.SetValue('rbot.accuracy.weapon.sniper.doublefire', 0)
		gui.SetValue('rbot.accuracy.weapon.hpistol.doublefire', 0)
		gui.SetValue('rbot.accuracy.weapon.pistol.doublefire', 0)
	end
end
callbacks.Register('Draw', dtbind)

--------------------------------

--Double Fire speed
local function handledt()
	if not engine.GetServerIP() then
		return
	end
	if not entities.GetLocalPlayer():IsAlive() then
		return
	end
	
	local getmaxprocessticks = client.GetConVar('sv_maxusrcmdprocessticks')
	
	local df_speed = {getmaxprocessticks - 3, getmaxprocessticks - 2, getmaxprocessticks - 1, getmaxprocessticks, getmaxprocessticks + 1, maxprocessticks_slider:GetValue()}
	local ping = entities.GetPlayerResources():GetPropInt("m_iPing", entities.GetLocalPlayer():GetIndex())
	
	if entities.GetLocalPlayer():GetWeaponID() == 38 or entities.GetLocalPlayer():GetWeaponID() == 11 
	or entities.GetLocalPlayer():GetWeaponID() == 40 or entities.GetLocalPlayer():GetWeaponID() == 9 
	or entities.GetLocalPlayer():GetWeaponID() == 1 then
		if gui.GetValue('rbot.accuracy.weapon.asniper.doublefire') == 2 or gui.GetValue('rbot.accuracy.weapon.asniper.doublefire') == 1
		or gui.GetValue('rbot.accuracy.weapon.scout.doublefire') == 2 or gui.GetValue('rbot.accuracy.weapon.asniper.doublefire') == 1
		or gui.GetValue('rbot.accuracy.weapon.sniper.doublefire') == 2 or gui.GetValue('rbot.accuracy.weapon.asniper.doublefire') == 1
		or gui.GetValue('rbot.accuracy.weapon.hpistol.doublefire') == 2 or gui.GetValue('rbot.accuracy.weapon.asniper.doublefire') == 1
		or gui.SetValue('rbot.accuracy.weapon.pistol.doublefire') == 2 or gui.SetValue('rbot.accuracy.weapon.pistol.doublefire') == 1 then
			if doublefire_speed:GetValue() == 0 then
				gui.SetValue('misc.fakelatency.enable', 0)
				if ping <= 5 then
					sv_maxusrcmdprocessticks:SetValue(getmaxprocessticks + 1)
				elseif ping <= 20 then
					sv_maxusrcmdprocessticks:SetValue(getmaxprocessticks)
				elseif ping <= 50 then
					sv_maxusrcmdprocessticks:SetValue(getmaxprocessticks - 1)
				elseif ping <= 80 then
					sv_maxusrcmdprocessticks:SetValue(getmaxprocessticks - 2)
				elseif ping > 80 then
					sv_maxusrcmdprocessticks:SetValue(getmaxprocessticks - 3)
				end
			elseif doublefire_speed:GetValue() >= 1 then
				sv_maxusrcmdprocessticks:SetValue(df_speed[doublefire_speed:GetValue()])
			end
		end
	else
		if maxprocessticks_combo:GetValue() == 0 then
			sv_maxusrcmdprocessticks:SetValue(getmaxprocessticks)
		elseif maxprocessticks_combo:GetValue() == 1 then
			sv_maxusrcmdprocessticks:SetValue(16)
		elseif maxprocessticks_combo:GetValue() == 2 then
			sv_maxusrcmdprocessticks:SetValue(6)
		elseif maxprocessticks_combo:GetValue() == 3 then
			sv_maxusrcmdprocessticks:SetValue(maxprocessticks_slider:GetValue())
		end
	end
end
callbacks.Register('CreateMove', handledt)

--------------------------------

--Fakeduck speed
local function fakeduck_speed()
	if not engine.GetServerIP() then
		return
	end
	if not entities.GetLocalPlayer():IsAlive() then
		return
	end
	
	local getmaxprocessticks = client.GetConVar('sv_maxusrcmdprocessticks')
	
	local fakeduck_accuracy = {getmaxprocessticks - 2, getmaxprocessticks - 1, getmaxprocessticks, getmaxprocessticks + 2, getmaxprocessticks + 3, maxprocessticks_slider:GetValue()}
	local fakeduck_inaccuracy = {getmaxprocessticks - 2, getmaxprocessticks - 1, getmaxprocessticks, maxprocessticks_slider:GetValue()}
	
	if fakeduck_type:GetValue() == 0 then
		if maxprocessticks_combo:GetValue() == 0 then
			gui.SetValue('rbot.antiaim.extra.fakecrouchstyle', 1)
		elseif maxprocessticks_combo:GetValue() == 1 then
			gui.SetValue('rbot.antiaim.extra.fakecrouchstyle', 1)
		end
	elseif fakeduck_type:GetValue() == 1 then
		gui.SetValue('rbot.antiaim.extra.fakecrouchstyle', 0)
	elseif fakeduck_type:GetValue() == 2 then
		gui.SetValue('rbot.antiaim.extra.fakecrouchstyle', 1)
	end
	
	if input.IsButtonDown(Fakeduck:GetValue()) then 
		if fakeduck_type:GetValue() == 0 then
			sv_maxusrcmdprocessticks:SetValue(getmaxprocessticks - 1)
		elseif fakeduck_type:GetValue() == 1 then
			sv_maxusrcmdprocessticks:SetValue(fakeduck_accuracy[fakeduck_speed_accuracy:GetValue() + 1])
		elseif fakeduck_type:GetValue() == 2 then
			sv_maxusrcmdprocessticks:SetValue(fakeduck_inaccuracy[fakeduck_speed_inaccuracy:GetValue() + 1])
		end
	else
		return
	end
end
callbacks.Register('Draw', fakeduck_speed)

--------------------------------

local function fakelags()
	if not engine.GetServerIP() then
		return	
	end
	if not entities.GetLocalPlayer():IsAlive() then
		return
	end
	
	local getmaxprocessticks = client.GetConVar('sv_maxusrcmdprocessticks')
	gui.SetValue('misc.fakelag.enable', 1)
	gui.SetValue('misc.fakelag.type', 0)
	
	if fakelags_type:GetValue() == 0 then
		if maxprocessticks_combo:GetValue() == 0 then
			gui.SetValue('misc.fakelag.factor', getmaxprocessticks)
		elseif maxprocessticks_combo:GetValue() == 1 then
			gui.SetValue('misc.fakelag.factor', 16)
		elseif maxprocessticks_combo:GetValue() == 2 then
			gui.SetValue('misc.fakelag.factor', 6)
		elseif maxprocessticks_combo:GetValue() == 3 then
			gui.SetValue('misc.fakelag.factor', maxprocessticks_slider:GetValue())
		end
	elseif fakelags_type:GetValue() == 1 then
		gui.SetValue('misc.fakelag.factor', fakelags_factor:GetValue())
	elseif fakelags_type:GetValue() == 2 then
		local jitter = math.random(fakelags_factor:GetValue() - 1, fakelags_factor:GetValue())
		gui.SetValue('misc.fakelag.factor', jitter)
	end
end
callbacks.Register('Draw', fakelags)

--------------------------------

--Double fire modes 1 and 2
--Based on Chicken4676 and John.k scripts (https://aimware.net/forum/thread/148350, https://aimware.net/forum/thread/101070)
local function entities_check()
    local LocalPlayer = entities.GetLocalPlayer();
    local Player
    if LocalPlayer ~= nil then
        Player = LocalPlayer:GetAbsOrigin()
        if (math.floor((entities.GetLocalPlayer():GetPropInt("m_fFlags") % 4) / 2) == 1) then
            z = 46
        else
            z = 64
        end
        Player.z = Player.z + LocalPlayer:GetPropVector("localdata", "m_vecViewOffset[0]").z
        return Player, LocalPlayer
    end
end
function predict_velocity(entity, prediction_amount)
	local VelocityX = entity:GetPropFloat( "localdata", "m_vecVelocity[0]" );
	local VelocityY = entity:GetPropFloat( "localdata", "m_vecVelocity[1]" );
	local VelocityZ = entity:GetPropFloat( "localdata", "m_vecVelocity[2]" );
	
	absVelocity = {VelocityX, VelocityY, VelocityZ}
	
	pos_ = {entity:GetAbsOrigin()}
	
	modifed_velocity = {vector.Multiply(absVelocity, prediction_amount)}
	
	
	return {vector.Subtract({vector.Add(pos_, modifed_velocity)}, {0,0,0})}
end
local function is_vis(LocalPlayerPos)
    local is_vis = false
    local players = entities.FindByClass("CCSPlayer")
    local fps = 4
    for i, player in pairs(players) do
        if player:GetTeamNumber() ~= entities.GetLocalPlayer():GetTeamNumber() and player:IsPlayer() and entities_check() ~= nil and player:IsAlive() then			
            for i = 0, 18 do
				if 	i == 0 or
					i == 3 or
					i == 6 or
					i == 16 or
					i == 18 then
					for x = 0, fps do
						local HitboxPos = player:GetHitboxPosition(i)

						if x == 0 then
							HitboxPos.x = HitboxPos.x
							HitboxPos.y = HitboxPos.y
						elseif x == 1 then
							HitboxPos.x = HitboxPos.x
							HitboxPos.y = HitboxPos.y + 4
						elseif x == 2 then
							HitboxPos.x = HitboxPos.x
							HitboxPos.y = HitboxPos.y - 4
						elseif x == 3 then
							HitboxPos.x = HitboxPos.x + 4
							HitboxPos.y = HitboxPos.y
						elseif x == 4 then
							HitboxPos.x = HitboxPos.x - 4
							HitboxPos.y = HitboxPos.y
						end

						local c = (engine.TraceLine(LocalPlayerPos, HitboxPos, 0x1)).contents
						
						local x,y = client.WorldToScreen(LocalPlayerPos)
						local x2,y2 = client.WorldToScreen(HitboxPos)
						
						--Debug
						--if c == 0 then draw.Color(0,255,0) else draw.Color(225,0,0) end
						--if x and x2 then
						--	draw.Line(x,y,x2,y2)
						--end
						--Debug
						
						if c == 0 then
							is_vis = true
							break
						end
					end
				end
            end
        end
    end
    return is_vis
end
local function doublefire_modes()
	if not engine.GetServerIP() then
		return
	end
	if not entities.GetLocalPlayer():IsAlive() then
		return
	end
	if not doublefire_enable:GetValue() then
		gui.SetValue("misc.speedburst.enable", 0)
		return
	end

	if doublefire_mode:GetValue() == 0 then
--		if entities.GetLocalPlayer():GetWeaponID() == 38
--		or entities.GetLocalPlayer():GetWeaponID() == 11
--		or entities.GetLocalPlayer():GetWeaponID() == 1 then 
			gui.SetValue('misc.speedburst.enable', 0)
			gui.SetValue('misc.speedburst.key', 'None')
--		end
		return
	end
	
--	if entities.GetLocalPlayer():GetWeaponID() == 38
--	or entities.GetLocalPlayer():GetWeaponID() == 11
--	or entities.GetLocalPlayer():GetWeaponID() == 1 then 	
		local Player, LocalPlayer = entities_check()
		if doublefire_mode:GetValue() == 1 then
			gui.SetValue('misc.fakelag.type', 1)
			gui.SetValue('misc.fakelag.factor', 7)
			gui.SetValue("misc.speedburst.enable", 1)
			gui.SetValue('misc.speedburst.key', 'None')
			
			if input.IsButtonDown('Space') then
				return
			end
			
			local velocity = math.sqrt(entities.GetLocalPlayer():GetPropFloat( "localdata", "m_vecVelocity[0]" ) ^ 2 + entities.GetLocalPlayer():GetPropFloat( "localdata", "m_vecVelocity[1]" ) ^ 2)
			
			if LocalPlayer then
				local perfect_prediction_velocity;
				if doublefire_prediction_mode:GetValue() == 0 then
					perfect_prediction_velocity = doublefire_prediction_value:GetValue() + 0.200
				elseif doublefire_prediction_mode:GetValue() == 1 then
					perfect_prediction_velocity = doublefire_prediction_value:GetValue() + 0.200 + (velocity / 10000)
				end
				--Debug
				--draw.TextShadow(1000, 500, perfect_prediction_velocity .. ' predict 1 (off dt)', 255, 255, 255, 255)
				--Debug
				local prediction = predict_velocity(LocalPlayer, perfect_prediction_velocity)
				local my_pos = LocalPlayer:GetAbsOrigin()
				
				local x,y,z = vector.Add(
					{my_pos.x, my_pos.y, my_pos.z},
					{prediction[1], prediction[2], prediction[3]}
				)
			
				local LocalPlayer_predicted_pos = Vector3(x,y,z)
				LocalPlayer_predicted_pos.z = LocalPlayer_predicted_pos.z + LocalPlayer:GetPropVector("localdata", "m_vecViewOffset[0]").z
			
				if is_vis(LocalPlayer_predicted_pos) then
					gui.SetValue('rbot.accuracy.weapon.asniper.doublefire', 0)
					gui.SetValue('rbot.accuracy.weapon.scout.doublefire', 0)
					gui.SetValue('rbot.accuracy.weapon.sniper.doublefire', 0)
					gui.SetValue('rbot.accuracy.weapon.hpistol.doublefire', 0)
					gui.SetValue('rbot.accuracy.weapon.pistol.doublefire', 0)
				else
					gui.SetValue('rbot.accuracy.weapon.asniper.doublefire', 2)
					gui.SetValue('rbot.accuracy.weapon.scout.doublefire', 2)
					gui.SetValue('rbot.accuracy.weapon.sniper.doublefire', 2)
					gui.SetValue('rbot.accuracy.weapon.hpistol.doublefire', 2)
					gui.SetValue('rbot.accuracy.weapon.pistol.doublefire', 2)
				end
			end
			if LocalPlayer then
				local perfect_prediction_velocity;
--				local perfect_prediction_velocity = doublefire_prediction_value:GetValue() + (velocity / 10000)
--				local perfect_prediction_velocity = 0.125 + (velocity / 10000)
--				local perfect_prediction_velocity = 0.160 - (velocity / 5000)
				if doublefire_prediction_mode:GetValue() == 0 then
					perfect_prediction_velocity = doublefire_prediction_value:GetValue()
				elseif doublefire_prediction_mode:GetValue() == 1 then
					perfect_prediction_velocity = doublefire_prediction_value:GetValue() + (velocity / 10000)
				end
				--Debug
				--draw.TextShadow(1000, 515, perfect_prediction_velocity .. ' predict 2 (on dt)', 255, 255, 255, 255)
				--Debug
				local prediction = predict_velocity(LocalPlayer, perfect_prediction_velocity)
				local my_pos = LocalPlayer:GetAbsOrigin()
				
				local x,y,z = vector.Add(
					{my_pos.x, my_pos.y, my_pos.z},
					{prediction[1], prediction[2], prediction[3]}
				)
			
				local LocalPlayer_predicted_pos = Vector3(x,y,z)
				LocalPlayer_predicted_pos.z = LocalPlayer_predicted_pos.z + LocalPlayer:GetPropVector("localdata", "m_vecViewOffset[0]").z
			
				if is_vis(LocalPlayer_predicted_pos) then
					gui.SetValue('rbot.accuracy.weapon.asniper.doublefire', 2)
					gui.SetValue('rbot.accuracy.weapon.scout.doublefire', 2)
					gui.SetValue('rbot.accuracy.weapon.sniper.doublefire', 2)
					gui.SetValue('rbot.accuracy.weapon.hpistol.doublefire', 2)
					gui.SetValue('rbot.accuracy.weapon.pistol.doublefire', 2)
				else
					return
				end
			end
		end
--	end
end
callbacks.Register('Draw', doublefire_modes)

--------------------------------

--Disable fakelags on Revolver
local function revolver()
	if not revolver_check:GetValue() then
		return
	end
	if not engine.GetServerIP() then
		return
	end
	if not entities.GetLocalPlayer():IsAlive() then
		return
	end
	
	if entities.GetLocalPlayer():GetWeaponID() == 64 then
		if input.IsButtonDown(Fakeduck:GetValue()) then
			gui.SetValue('misc.fakelag.factor', 14)
		else
			gui.SetValue('misc.fakelag.factor', 13)
		end
	else
		return
	end
end
callbacks.Register('Draw', revolver)

--------------------------------

--Nonscope hitchance
local function nonescopehc()
	if not nonescopehc_enable:GetValue() then
		return
	end
	if not engine.GetServerIP() then
		return
	end
	if not entities.GetLocalPlayer():IsAlive() then
		return
	end

	Scoped = entities.GetLocalPlayer():GetPropBool("m_bIsScoped");
	
	if entities.GetLocalPlayer():GetWeaponID() == 38
	or entities.GetLocalPlayer():GetWeaponID() == 11 then
		gui.SetValue('rbot.aim.automation.scope', 0)
		if Scoped then
			gui.SetValue(AutosniperHitchance, nonescopehc_scope:GetValue())
			if doublefire_mode:GetValue() == 1 then
				if doublefire_enable:GetValue() then
					gui.SetValue(AutosniperDTHitchance, nonescopehc_dt_scope:GetValue() / 2)
				else
					gui.SetValue(AutosniperDTHitchance, nonescopehc_dt_scope:GetValue())
				end
			else
				gui.SetValue(AutosniperDTHitchance, nonescopehc_dt_scope:GetValue())
			end
		else
			gui.SetValue(AutosniperHitchance, nonescopehc_regular:GetValue())
			if doublefire_mode:GetValue() == 1 then
				if doublefire_enable:GetValue() then
					gui.SetValue(AutosniperDTHitchance, nonescopehc_dt_regular:GetValue() / 1.5)
				else
					gui.SetValue(AutosniperDTHitchance, nonescopehc_dt_regular:GetValue())
				end
			else
				gui.SetValue(AutosniperDTHitchance, nonescopehc_dt_regular:GetValue())
			end
		end
	else
		gui.SetValue('rbot.aim.automation.scope', 2)
	end
end
callbacks.Register('Draw', nonescopehc)

--------------------------------	

--AutoPeek
--Semi-pasted from sestain's script.
local function SavedValues()
	ScarDtValue 				= gui.GetValue('rbot.accuracy.weapon.asniper.doublefire')
	ScoutDtValue 				= gui.GetValue('rbot.accuracy.weapon.scout.doublefire')
	AwpDtValue 					= gui.GetValue('rbot.accuracy.weapon.sniper.doublefire')
	DeagleDtValue 				= gui.GetValue('rbot.accuracy.weapon.hpistol.doublefire')
	PistolDtValue 				= gui.GetValue('rbot.accuracy.weapon.pistol.doublefire')
	
	FakelatencyEnableValue 		= gui.GetValue('misc.fakelatency.enable')
	FakelatencyAmountValue 		= gui.GetValue('misc.fakelatency.amount')
	FakelatencyKeyValue			= gui.GetValue('misc.fakelatency.key')
	
	FreestandingLeftValue  		= gui.GetValue('rbot.antiaim.left')
	FreestandingRightValue		= gui.GetValue('rbot.antiaim.right')
	FreestandingAtedgesValue 	= gui.GetValue('rbot.antiaim.advanced.autodir.edges')
	FreestandingAttargetsValue 	= gui.GetValue('rbot.antiaim.advanced.autodir.targets')
end
local dt_autopeek_state = false
local function dt_autopeek()
	if not engine.GetServerIP() then
		return
	end
	if not entities.GetLocalPlayer():IsAlive() then
		return
	end
	
	local getmaxprocessticks = client.GetConVar('sv_maxusrcmdprocessticks')
	
	if entities.GetLocalPlayer():GetWeaponID() == 38 
	or entities.GetLocalPlayer():GetWeaponID() == 11
	or entities.GetLocalPlayer():GetWeaponID() == 40
	or entities.GetLocalPlayer():GetWeaponID() == 9
	or entities.GetLocalPlayer():GetWeaponID() == 1 then
		if input.IsButtonDown(AutoPeek:GetValue()) then 
			if dt_on_autopeek:GetValue() then
				gui.SetValue('rbot.accuracy.weapon.asniper.doublefire', 2)
				gui.SetValue('rbot.accuracy.weapon.scout.doublefire', 2)
				gui.SetValue('rbot.accuracy.weapon.sniper.doublefire', 2)
				gui.SetValue('rbot.accuracy.weapon.hpistol.doublefire', 2)
				gui.SetValue('rbot.accuracy.weapon.pistol.doublefire', 2)
			end
			if dt_on_autopeek_pingspike:GetValue() then
				gui.SetValue('misc.fakelatency.enable', 1)
				gui.SetValue('misc.fakelatency.amount', 200)
				gui.SetValue('misc.fakelatency.key', 'None')
			end
			if dt_on_autopeek_freestanding:GetValue() then
				gui.SetValue('rbot.antiaim.left', 120)
				gui.SetValue('rbot.antiaim.right', -120)
				gui.SetValue('rbot.antiaim.advanced.autodir.edges', 1)
				gui.SetValue('rbot.antiaim.advanced.autodir.targets', 0)
			end
			if dt_on_autopeek_optimalticks:GetValue() and dt_on_autopeek:GetValue() then
				sv_maxusrcmdprocessticks:SetValue(getmaxprocessticks)
			end
			
			dt_autopeek_state = true
		end
		if input.IsButtonReleased(AutoPeek:GetValue()) then 
			if dt_on_autopeek:GetValue() then
				gui.SetValue('rbot.accuracy.weapon.asniper.doublefire', ScarDtValue)
				gui.SetValue('rbot.accuracy.weapon.scout.doublefire', ScoutDtValue)
				gui.SetValue('rbot.accuracy.weapon.sniper.doublefire', AwpDtValue)
				gui.SetValue('rbot.accuracy.weapon.hpistol.doublefire', DeagleDtValue)
				gui.SetValue('rbot.accuracy.weapon.pistol.doublefire', PistolDtValue)
			end
			if dt_on_autopeek_pingspike:GetValue() then
				gui.SetValue('misc.fakelatency.enable', FakelatencyEnableValue)
				gui.SetValue('misc.fakelatency.amount', FakelatencyAmountValue)
				gui.SetValue('misc.fakelatency.key', FakelatencyKeyValue)
			end
			if dt_on_autopeek_freestanding:GetValue() then
				gui.SetValue('rbot.antiaim.left', FreestandingLeftValue)
				gui.SetValue('rbot.antiaim.right', FreestandingRightValue)
				gui.SetValue('rbot.antiaim.advanced.autodir.edges', FreestandingAtedgesValue)
				gui.SetValue('rbot.antiaim.advanced.autodir.targets', FreestandingAttargetsValue)
			end
			if dt_on_autopeek_optimalticks:GetValue() and dt_on_autopeek:GetValue() then
				return
			end
				
			dt_autopeek_state = false
		end
	end
	
	if not dt_autopeek_state then
		SavedValues()
	end
end
callbacks.Register('Draw', 'dt_autopeek', dt_autopeek);	
	
--------------------------------

--Unlock Inventory and Force crosshair
local function inventory_and_crosshair()
	panorama.RunScript([[ LoadoutAPI.IsLoadoutAllowed = () => { return true; }; ]])
	if force_crosshair:GetValue() then
		client.SetConVar("weapon_debug_spread_show", 3, true)
	else
		client.SetConVar("weapon_debug_spread_show", 0, true)
	end
end
callbacks.Register('Draw', "inventory_and_crosshair", inventory_and_crosshair)

--Pasted Aspect Ratio
local Aspect_Ratio_table = {};
local function gcd(a, b)
	while a ~= 0 do
		a, b = math.fmod(b, a), a
	end   
	return b
end
local function Set_Aspect_Ratio(aspect_ratio_multiplier)
	local screen_width, screen_height = draw.GetScreenSize()
	local aspectratio_value = (screen_width*aspect_ratio_multiplier)/screen_height
    client.SetConVar( "r_aspectratio", tonumber(aspectratio_value), true)
end
local function Aspect_Ratio()
	local screen_width, screen_height = draw.GetScreenSize()
	for i = 1, 200 do
		local i2 = 2 - i * 0.01
		local divisor = gcd(screen_width * i2, screen_height)
		if screen_width * i2 / divisor < 100 or i2 == 1 then
			Aspect_Ratio_table[i] = screen_width * i2 / divisor .. ":" .. screen_height / divisor
		end
	end
	local aspect_ratio = 2 - aspect_ratio:GetValue()*0.01
	Set_Aspect_Ratio(aspect_ratio)
end
callbacks.Register('Draw', "Aspect Ratio", Aspect_Ratio)

--------------------------------

--Pasted Night Mode
local function Night_Mode()
	local controller = entities.FindByClass("CEnvTonemapController")[1];
	if(controller) then
		controller:SetProp("m_bUseCustomAutoExposureMin", 1);
		controller:SetProp("m_bUseCustomAutoExposureMax", 1);

		local value = night_mode:GetValue()
		controller:SetProp("m_flCustomAutoExposureMin", value / 100);
		controller:SetProp("m_flCustomAutoExposureMax", value / 100);
	end
end
callbacks.Register('Draw', "Night Mode", Night_Mode)

--------------------------------

--Drawing ticks
local font = draw.CreateFont('Andre V', 17)
local function draw_ticks_and_circle()
	if not engine.GetServerIP() then
		return
	end
	if not entities.GetLocalPlayer():IsAlive() then
		return
	end
	
	draw.SetFont(font)
	local x, y = draw.GetScreenSize()
	local w, h = draw.GetTextSize('16 TICKS')
	local DrawingOverRapidfireX = toint(x / 2 - (w / 2))
	local DrawingOverRapidfireY = toint(y / 1.073 - (h / 2))

	if draw_ticks:GetValue() then
		if entities.GetLocalPlayer():GetWeaponID() == 38 or entities.GetLocalPlayer():GetWeaponID() == 11 
		or entities.GetLocalPlayer():GetWeaponID() == 40 or entities.GetLocalPlayer():GetWeaponID() == 9 
		or entities.GetLocalPlayer():GetWeaponID() == 1 then
			if gui.GetValue('rbot.accuracy.weapon.asniper.doublefire') == 1 or gui.GetValue('rbot.accuracy.weapon.asniper.doublefire') == 2
			or gui.GetValue('rbot.accuracy.weapon.scout.doublefire') == 1 or gui.GetValue('rbot.accuracy.weapon.asniper.doublefire') == 2
			or gui.GetValue('rbot.accuracy.weapon.sniper.doublefire') == 1 or gui.GetValue('rbot.accuracy.weapon.asniper.doublefire') == 2
			or gui.GetValue('rbot.accuracy.weapon.hpistol.doublefire') == 1 or gui.GetValue('rbot.accuracy.weapon.asniper.doublefire') == 2 then
				draw.Color(draw_ticks_color:GetValue())
				draw.TextShadow(DrawingOverRapidfireX, DrawingOverRapidfireY, sv_maxusrcmdprocessticks:GetValue() .. ' TICKS', ticks_draw_color)
			end
		end
	end
	if draw_circle:GetValue() then
		local choke = time_to_ticks(globals.CurTime() - entities.GetLocalPlayer():GetPropFloat( "m_flSimulationTime")) + 2
		draw.Color(draw_circle_color:GetValue())
		draw.OutlinedCircle(toint(x / 2), toint(y / 2), choke)
	end
end
callbacks.Register('Draw', 'draw_ticks_and_circle', draw_ticks_and_circle)
